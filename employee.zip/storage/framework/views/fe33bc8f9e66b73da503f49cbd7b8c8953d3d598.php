<?php $__env->startSection('content'); ?>
 
<div class="container">

<a href="<?php echo url("/add"); ?>" class="btn btn-info">Add New Employee</a>
<br><br>
 
<table class="table table-bordered table-striped" id="laravel_datatable">
   <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Address</th>
                <th>Created date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>

            <?php //dd($data); ?>
            <?php if(isset($data)): ?>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($result->name); ?></td>
                    <td><?php echo e($result->email); ?></td>
                    <td><?php echo e($result->mobile); ?></td>
                    <td><?php echo e($result->address); ?></td>
                    <td><?php echo e($result->created_at); ?></td>
                    <td><a href="<?php echo url("/edit/".$result->id); ?>">Edit</a> | <a href="<?php echo url("/delete/".$result->id); ?>">Delete</a></td>
                </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>   
</table>
</div>

<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('script'); ?>

<script>

  $('#laravel_datatable').DataTable({
               
  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\employee\resources\views/employee/list.blade.php ENDPATH**/ ?>