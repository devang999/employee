@extends('layouts.app')

@section('content')
 
<div class="container">



<a href="javascript:void(0)" class="btn btn-info ml-3" id="create-new-user">Add New Employee</a>
<br><br>
 
<table class="table table-bordered table-striped" id="laravel_datatable">
   <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Created date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @if(isset($data))
              @foreach($data as $result)

                <tr>
                    <td>{{ $result->name }}</td>
                    <td>{{ $result->email }}</td>
                    <td>{{ $result->phone }}</td>
                    <td>{{ $result->address }}</td>
                    <td>{{ $result->created_date }}</td>
                    <td><a href="">Edit</a></td>
                </tr>

              @endforeach
            @endif
            </tbody>   
</table>
</div>

@endsection
 
@section('script')

<script>

  $('#laravel_datatable').DataTable({
               
  });
</script>

@endsection