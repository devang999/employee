<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\FieldRequest;

use App\Employe;

class EmployeController extends Controller
{
    
	public function __construct()
    {
        $this->middleware('auth');
    }


    public function index(){
		 
		$data = Employe::where('is_delete','N')
               ->orderBy('name', 'desc')
               ->get();
			  // dd($data);
		return view('employee.list',compact('data'));
	}


	public function createview(){

		return view('employee.add');
	}

	public function storeemp(FieldRequest  $request){


		// Server Side Validation 
		$validatedData = $request->validated();
        \App\Form::create($validatedData);

		//dd($request->all());
		$employee = new employe;
		$employee->name = $request['name'];
		$employee->email = $request['email'];
		$employee->address = $request['address'];
		$employee->mobile = $request['mobile'];
		$employee->is_delete = 'N';
		$employee->created_at = date('Y-m-d h:i:s');
		$employee->save();

		return redirect('/employee');
	}
	public function editemp($id){
		if(isset($id))
		{
			$data = Employe::where('is_delete','N')
				->where(['id'=>$id])
                ->get();
			   
			return view('employee.edit',compact('data'));	
		}
		

	}

	public function update(FieldRequest $request){

		// Server Side Validation 
		$validatedData = $request->validated();
        \App\Form::create($validatedData);


		//dd($request->all());
		$update = Employe::where('id',$request['id'])->update(['name'=>$request['name'],'address'=>$request['address'],'email'=>$request['email'],'mobile'=>$request['mobile'],'updated_at'=>date('Y-m-d h:i:s')]);

		return redirect('/employee');
	}

	public function deleteemp($id){
		//echo $id; exit;
		if(isset($id))
		{
			$update = Employe::where('id',$id)->update(['is_delete'=>'Y']);

		return redirect('/employee');	
		}
		

	}

}
